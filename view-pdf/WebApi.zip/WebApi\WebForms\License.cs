using GrapeCity.Documents.Pdf;

namespace GcPdfViewerSupportApiDemo
{
    public class Licensing
    {
        public static void AddLicenseKeys()
        {
            // Set GcPdf license key:
            //GcPdfDocument.SetLicenseKey("<key>");
        }
    }
}